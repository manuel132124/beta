<?php

echo"Tablas de multiplicar</p>";
$num=5;

for ($i = 0; $i < 12; $i++) {
    $mul=$i*$num;
    echo "<p>multiplos: ".$mul;
}

?>