<?php

$a=50;
echo "<p>primer valor</p>".$a;
$b= 50;
echo "</p>segundo valor</p>".$b;

$suma= $a+ $b;

echo "</p>la suma es ".$suma;

?>
