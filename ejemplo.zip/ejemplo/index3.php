<?php
echo"<p>Intercambio de valores</p>";
$a=10;
echo "a=".$a;
$b=15;
echo "b=".$b;
$c=5;
echo "<p>cambios</p>";
$cam=$b-$c;
$cam2=$a+$c;
echo "a=".$cam2;
echo "b=".$cam;



?>