<?php

echo"Meses del año</p>";
$num=9;

if ($num == 1) {
    echo "enero";
} elseif ($num == 2) {
    echo "febrero";
} elseif ($num == 3) {
    echo "marzo";
} elseif ($num == 4) {
    echo "abril";
} elseif ($num == 5) {
    echo "mayo";
} elseif ($num == 6) {
    echo "junio";
} elseif ($num == 7) {
    echo "julio";
} elseif ($num == 8) {
    echo "agosto";
} elseif ($num == 9) {
    echo "septiembre";
} elseif ($num == 10) {
    echo "octubre";
} elseif ($num == 11) {
    echo "noviembre";
} elseif ($num == 12) {
    echo "diciembre";
} else {
    echo "Número de mes no válido";
}
?>




