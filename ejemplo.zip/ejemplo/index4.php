<?php
echo"Número par o impar</p>";
$a=46;


if ($a %2== 0) {
    echo "<p>el numero: ".$a." es par</P>";
} else {
    echo "<P>el numero: ".$a." es impar";
}
?>