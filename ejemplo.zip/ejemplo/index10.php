<?php

$num=20;
for ($i = 0; $i <= $num; $i++) {
    if ($i %2== 0) {
        echo"<p>numero pares: ".$i++;}
        
}