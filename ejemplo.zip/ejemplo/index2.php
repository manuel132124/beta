<?php

echo"Área de un círculo</p>";
$a=5;
echo"area: ".$a;
const pi=3.1416;

$radio= pi*$a*$a;
echo"<P>el radio del circulo es: </p>".$radio;

?>